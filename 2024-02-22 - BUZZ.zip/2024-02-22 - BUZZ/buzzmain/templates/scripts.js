/* Functions for adding FAST headings */
var currentSuggestIndex = "suggestall";

function setUpFAST() {
    $('#breakerbox').autocomplete({
        source: autoSubjectBreaker,
        create: function () {
            $(this).data('ui-autocomplete')._renderItem = function (ul, item) {
                var retValue = "<strong>" + item.auth + "</strong>";
                if(item.type=="alt") retValue = item.label + "<em> USE </em>" + retValue;
                return $( "<li></li>" ).data( "ui-autocomplete-item", item ).append( '<a class="text-decoration-none">' + retValue + '</a>' ).appendTo( ul );
            };
        },
        minLength: 1,
        select: function(event, ui) {
            selected = true;
        },
        open: function(event, ui) {
            selected = false;
        },
        close: function(event, ui) {
            if(selected) this.select();
        }
    })
}

function autoSubjectBreaker(request, response) {
    return autoSubject(request, response, breakerStyle, $('#breakerfacetlist option:selected').val());
}

/* END Functions for adding FAST headings */

/* Functions for record navigation */

async function nextCommon() {
    var resp = await fetch('record_number');
    var ht = await resp.text()
    $('#pos_input_records').text(ht);
    resp = await fetch('search_oclc');
    ht = await resp.text()
    $('#oclc_header').html($(ht).filter('#oclc_header_template'));
    $('#oclc').html($(ht).filter('#oclc_records_template'));
    resp = await fetch('validate');
    ht = await resp.text()
    $('#validate').html($(ht));
    $('.toast').removeClass('show');
    setupHighlighter();
}

async function nextRecord() {
    let data = new FormData();
    data.append('action',  'next');
    var resp = await fetch('next_record', {
        'method': 'POST',
        'body': data,
    });
    var ht = await resp.text()
    $('#marc').html($(ht));
    nextCommon();
}

async function nextRecordSaved() {
    let data = new FormData();
    data.append('action',  'save');
    data.append("locked_marc", $('#locked_marc').val());
    data.append("editable_marc", $('#editable_marc').val());
    const resp = await fetch('next_record', {
        'method': 'POST',
        'body': data,
    });
    var ht = await resp.text()
    $('#marc').html($(ht));
    nextCommon();
}

function saveBL() {
    let data = new FormData();
    data.append("locked_marc", $('#locked_marc').val());
    data.append("editable_marc", $('#editable_marc').val());
    const resp = fetch('saveBL', {
        'method': 'POST',
        'body': data,
    });
}

function downloadBL() {
    let data = new FormData();
    data.append("locked_marc", $('#locked_marc').val());
    data.append("editable_marc", $('#editable_marc').val());
    const resp = fetch('downloadBL', {
        'method': 'POST',
        'body': data,
    });
}



/* END Functions for record navigation */

/* Functions for checking records */

function setupHighlighter(){
    var highlighter = $('#editable_marc').highlightTextarea({
        words: [{
            colour: 'red',
            words: ['^[^=<][^<]?[^<]?[^<]?',                                    //Field must be preceded by =
                '^=(?![A-Z0-9][A-Z0-9][A-Z0-9]\\b)[^<]?[^<]?[^<]?',             //Field tag must be three alphanumeric characters
                '=[A-Z0-9][A-Z0-9][A-Z0-9](?!  )[^<]?[^<]?',                    //Field tag must be followed by two spaces
                '=(?!LDR)(?!00)[A-Z0-9][A-Z0-9][A-Z0-9]  (?![0-9#][0-9#])[^<]?[^<]?',    //Indicators must be two numbers or # - EXCLUDE CONTROL FIELDS
                '=(?!LDR)(?!00)[A-Z0-9][A-Z0-9][A-Z0-9]  [0-9#][0-9#](?! )[^<]?',        //Indicators must be followed by a single space - EXCLUDE CONTROL FIELDS
                '=(?!LDR)(?!00)[A-Z0-9][A-Z0-9][A-Z0-9]  [0-9#][0-9#] [^\\$]',           //Field must contain some subfields
                '=(?:00[0-9]|LDR)  [a-z0-9#\\|]*[^a-z0-9#\\|<>\\n\r$]',         //Control fields must contain only alphanumeric characters, # or |
                '\\$([^a-z0-9<]|$)',                                            //Subfield codes must be a-z or 0-9
                '\\$(?=\\n)',                                                   //Subfield codes must not occur at the end of a line
                ]
            }, {
            colour: 'orange',
            words: ['=100  .. \\$a[A-Z][A-Z][A-Z]+',                        //Main entry in capital letters
                '=008  ......\\|',                                          //No 008 date type
                '^=(260|720|653)',                                          //260 or 720 field
                '\\$emain entry',                                           //$emain entry
                '^=245[^\\n]*edition',                                      //'edition' in 245
                '\\|\\$u',
                'Another copy',
                '^=(009|011|090|091|211|212|214|241|265|301|302|303|304|305|308|315|350|359|440|503|512|517|523|527|537|543|570|582|590|590|652|705|715|755|840|851|870|871|872|873)'   // obsolete fields
                ]
            }, {
            colour: 'green',
            words: ['(\\$.|\\b)pp*\\b\\.?',
                '(\\$.|\\b)illu?s?\\b\\.?',
                '(\\$.|\\b)facsi?m?s?\\b\\.?',
                '(\\$.|\\b)geneal\\b\\.?',
                '(\\$.|\\b)ports?\\b\\.?',
                '(\\$.|\\b)col\\b\\.?',
                '(\\$.|\\b)mins?\\b\\.?',
                'Held in OIOC',]
        }],
        resizable: true
    });
}

async function checkRecord() {
    let data = new FormData();
    data.append("locked_marc", $('#locked_marc').val());
    data.append("editable_marc", $('#editable_marc').val());
    const resp = await fetch('validate', {
        'method': 'POST',
        'body': data
    });
    var ht = await resp.text()
    console.log(ht)
    $('#validate').html($(ht));

    var serious = $('.ul_red').length;
    var moderate = $('.ul_orange').length;
    var ignorable = $('.ul_green').length;

    if (serious == 0) {
        $('#count_moderate_ok').html(moderate);
        $('#count_ignorable_ok').html(ignorable);
        $('#toast_record_success').addClass('show');
    } else {
        $('#count_moderate').html(moderate);
        $('#count_ignorable').html(ignorable);
        if (serious == 1) {
            $('#error_statement').html('There is 1 structural problem with your record. Please fix this before saving.');
        } else {
            $('#error_statement').html('There are ' + serious + ' structural problems with your record. Please fix these before saving.');
        }
        $('#toast_record_error').addClass('show');
    }
}

/* END Functions for checking records */

/* Functions for editing records */

async function add_FAST_to_record(field) {
    if (field.length > 0 && field.startsWith('=')) {
        let data = new FormData();
        data.append('action',  'add_single');
        data.append("locked_marc", $('#locked_marc').val());
        data.append("editable_marc", $('#editable_marc').val());
        data.append("field", field);
        const resp = await fetch('edit_record', {
        'method': 'POST',
        'body': data,
        });
        var ht = await resp.text()
        $('#marc').html($(ht));
    }
    setupHighlighter()
    $('#editable_marc').trigger('input');
    update_recently_used(field);
    $('#breakerbox').val('');
    $('#breakerbox').focus();
}

async function add_fields_to_record(fields) {
    if (fields.length > 0) {
        let data = new FormData();
        data.append('action',  'add_multiple');
        data.append("locked_marc", $('#locked_marc').val());
        data.append("editable_marc", $('#editable_marc').val());
        data.append("fields", fields.join('\n'));
        const resp = await fetch('edit_record', {
            'method': 'POST',
            'body': data
        });
        var ht = await resp.text()
        $('#marc').html($(ht));
    }
    setupHighlighter()
    $('#editable_marc').trigger('input');
}

async function add_holdings_to_record(shelfmark) {
    if (shelfmark.length > 3 && !(shelfmark.startsWith('['))) {
        let data = new FormData();
        let field = "=852  41 $aBritish Library$b" + $('#collectionList').val() + "$j" + shelfmark + "$z" + $('#methodAcquistiionList').val()
        if ($('#condition').val().length > 3 && !($('#condition').val().startsWith('['))) {
            field += "$qCopy at " + shelfmark + ". " + $('#condition').val()
        }
        data.append('action',  'add_single');
        data.append("locked_marc", $('#locked_marc').val());
        data.append("editable_marc", $('#editable_marc').val());
        console.log(field)
        data.append("field", field);
        const resp = await fetch('edit_record', {
        'method': 'POST',
        'body': data,
        });
        var ht = await resp.text()
        $('#marc').html($(ht));
        $('#shelfmark_success_statement').html('Added to record:<br/><br/><span class="font-monospace">' + field + '</span>');
        $('#toast_shelfmark_success').addClass('show');
    } else {
        $('#toast_shelfmark_error').addClass('show');
    }
    setupHighlighter()
    $('#editable_marc').trigger('input');
    $('#shelfmark').val('');
    $('#condition').val('');
    $('#shelfmark').focus();
}

function update_recently_used(field) {
    var already_listed = []
    $('#recently_used_fast a').each(function(){
        already_listed.push($(this).text());
    });
    if (field.length > 0 && field.startsWith('=') && $.inArray(field, already_listed) < 0) {
        $('#recently_used_fast').prepend('<li><a href="#" class="small px-0" onclick="add_FAST_to_record(\'' + field + '\')">' + field + '</a></li>')
    };
    $('#recently_used_fast li:gt(14)').remove();
}

/* END Functions for editing records */


/* Functions for searching OCLC */

async function searchOCLC() {
    var ht;
    let data = new FormData();
    data.append('action',  'new_search');
    const resp = await fetch('search_oclc', {
        "method": "POST",
        "body": data,
    });
    ht = await resp.text()
    $('#oclc_header').html($(ht).filter('#oclc_header_template'));
    $('#oclc').html($(ht).filter('#oclc_records_template'));
}

async function searchAgain() {
    let data = new FormData();
    data.append("title",  $('#reviseSearchTitle').val());
    data.append("au", $('#reviseSearchAuthor').val());
    data.append("isbn", $('#reviseSearchISBN').val());
    var ht;
    const resp = await fetch('search_again', {
        "method": "POST",
        "body": data,
    });
    ht = await resp.text()
    $('#oclc_header').html($(ht).filter('#oclc_header_template'));
    $('#oclc').html($(ht).filter('#oclc_records_template'));
}

function select_all_fields(rid){
    $('input.field_' + rid + ':checkbox').prop('checked', document.getElementById('select_all_fields_' + rid).checked);
}

function add_selected_fields(rid){
    var fields = [];
    $('input.field_' + rid + ':checkbox').each(function () {
        if ($(this).prop('checked')){
            fields.push($(this).val());
        }
        $(this).prop('checked', false);
    });
    $('#select_all_fields_' + rid).prop('checked', false);
    add_fields_to_record(fields)
    setupHighlighter()
    $('#editable_marc').trigger('input');
    //tidy_record();
}

/* END Functions for searching OCLC */

function replace_in_marc_record(to_replace, replace_with) {
    $('#editable_marc').val($('#editable_marc').val().replaceAll(to_replace, replace_with))
    $('#editable_marc').trigger('input');
}

function tidy_264() {
    $('#editable_marc').val($('#editable_marc').val().replaceAll(/(?<==264.*)\$a[\[\s\.]*s[\.\s]*[nl][\[\s\.:;]*(?=($|\$))/g, '$a[Place of publication not identified] :'))
    $('#editable_marc').val($('#editable_marc').val().replaceAll(/(?<==264.*)\$b[\[\s\.]*s[\.\s]*[nl][\[\s\.:;]*(?=($|\$))/g, '$b[publisher not identified],'))
    $('#editable_marc').val($('#editable_marc').val().replaceAll(/(?<==264.*)[\,.\s*;:]*$/g, '.').replaceAll(/(?<==26.*)-.$/g, ''))
    $('#editable_marc').trigger('input');
}

function tidy_300() {
    $('#editable_marc').val($('#editable_marc').val().replaceAll(/(?<==300.*)(\$.|\s*\b)pp*\b\.?\s*/g, '$1pages ')
        .replaceAll(/(?<==300.*)([0-9]+)pp*\b\.?\s*/g, '$1 pages ')
        .replaceAll(/(?<==300.*)(\$.|\s*\b)ports?\b\.?\s*/g, '$1portraits ')
        .replaceAll(/(?<==300.*)(\$.|\s*\b)col\b\.?\s*/g, '$1colour ')
        .replaceAll(/(?<==300.*)(\$.|\s*\b)illu?s?\b\.?\s*/g, '$1illustrations ')
        .replaceAll(/(?<==300.*)(\$.|\s*\b)facsi?m?s?\b\.?\s*/g, '$1facsimiles ')
        .replaceAll(/(?<==300.*)(\$.|\s*\b)geneal\b\.?\s*/g, '$1genealogical ')
        .replaceAll(/(?<==300.*) +,/g, ',')
        .replaceAll(/(?<==300  ...*) +/g, ' ')
        .replaceAll(/(?<==300.*)[\,.\s*;:]*$/g, '.'));
    $('#editable_marc').trigger('input');
}

function tidy_040_beng() {
    $('#editable_marc').val($('#editable_marc').val().replaceAll(/(=040.*)(\$b[^\$]*?)(\$|\b)/g, '$1$3'));
    $('#editable_marc').val($('#editable_marc').val().replaceAll(/(=040.*\$a[^\$]*?)(\$|\b)/g, '$1$beng$2'));
    $('#editable_marc').trigger('input');
}

function tidy_040_dUk() {
    $('#editable_marc').val($('#editable_marc').val().replaceAll(/(=040.*\$[bcd][^\$]*?)(\b|\$e)/g, '$1$dUk$2'));
    $('#editable_marc').val($('#editable_marc').val().replaceAll(/(\$dUk)+/g, '$dUk'));
    $('#editable_marc').trigger('input');
}

async function transliterate() {
    //TODO Improve HTML entity processing
    let data = new FormData();
    var old_field = $('#field_to_transliterate').text()
    data.append("from",  $('#transliterate_input_script').val());
    data.append("to", $('#transliterate_output_script').val());
    data.append("text", old_field);
    data.append("locked_marc", $('#locked_marc').html());
    data.append("editable_marc", $('#editable_marc').val());
    var new_fields;
    const resp = await fetch('transliterate', {
        "method": "POST",
        "body": data,
    });
    ht = await resp.text()
    if (ht == 'Cannot transliterate this field' ) {
        $('#from_transliterate').html('Cannot transliterate this field');
        $("#button_add_transliterated").hide();
        $("#button_transliterate").hide();
    } else {
        new_fields = ht.split('\n')
        $('#from_transliterate').html('<p id="from_transliterate" class="sm">Result:<br/><span id="" class="font-monospace">' + new_fields[0] + '</span><br/><span id="" class="font-monospace">' + new_fields[1] + '</span></p>');
        $("#button_add_transliterated").on("click", function(){
            $('#editable_marc').val($('#editable_marc').val().replace(old_field, ''));
            $('#editable_marc').trigger('input');
            add_fields_to_record(new_fields)
            $("#context-menu").removeClass("show").hide();
            setupHighlighter()
            $('#editable_marc').trigger('input');
            });
        $("#button_transliterate").hide();
        $("#button_add_transliterated").show();
    }
}

function contextMenu(event){
    if ($('#switch_transliteration').prop('checked')) {
        event.preventDefault();
        var t = $('#editable_marc')[0];
        var start = $('#editable_marc')[0].selectionStart;
        var line_no = (t.value.substr(0, start).split("\n").length);
        var line = t.value.split("\n")[line_no-1];
        const regexp = new RegExp('^=([09A-Z]|85)');
        if (regexp.test(line)) {
            $('#to_transliterate').html('Cannot transliterate this field');
            $("#button_transliterate").hide();
        } else {
            $('#to_transliterate').html('Field to transliterate: <span id="field_to_transliterate" class="font-monospace">' + line + '</span></p>');
            $("#button_transliterate").show();
        }
        $('#from_transliterate').html('');
        $("#button_add_transliterated").unbind('click');
        $("#button_add_transliterated").hide();
        var top = event.pageY + 10;
        var left = event.pageX + 10;
        $("#context-menu").css({
            display: "block",
            top: top,
            left: left
        }).addClass("show");
        return false;
    }
}