import html
import os
import regex as re
import sys
import unicodedata

from flask import Flask, request, redirect, render_template, url_for, send_from_directory
from aksharamukha import transliterate
from werkzeug.utils import secure_filename
from buzzmain.Marc.marc_tools import *


if getattr(sys, 'frozen', False):
    print('Template folder: ' + str(os.path.join(sys._MEIPASS, 'templates')))
    print('Static folder: ' + str(os.path.join(sys._MEIPASS, 'static')))
    app = Flask(__name__, template_folder=os.path.join(sys._MEIPASS, 'templates'), static_folder=os.path.join(sys._MEIPASS, 'static'))
else:
    app = Flask(__name__)

app.config['UPLOAD_FOLDER'] = os.path.join(os.getcwd(), 'uploads')
app.config['OUTPUT_FOLDER'] = os.path.join(os.getcwd(), 'output')
ALLOWED_EXTENSIONS = {'lex', 'mrc'}
app.secret_key = 'secret dino key'

class BuzzValues:

    def __init__(self):
        self.num_input_records = 0
        self.num_z_records = 0
        self.pos_input_records = 0
        self.filename = None
        self.input_records = {1: None}
        self.z_records = {1: None}
        self.query = None
        self.title = None
        self.au = None
        self.isbn = None
        self.writer = MARCWriter
        self.reader = MARCReader
        self.blid = None


BZ = BuzzValues()


def allowed_file(fname):
    """Function to check whether a filename is valid"""
    return '.' in fname and fname.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/favicon.ico')
def favicon():
    if getattr(sys, 'frozen', False):
        print(os.path.join(sys._MEIPASS, 'static'))
        return send_from_directory(os.path.join(sys._MEIPASS, 'static'), 'favicon.ico', mimetype='image/vnd.microsoft.icon')


@app.route('/')
@app.route('/index')
@app.route('/home')
def index():
    print('Starting up...')
    return render_template('index.html')


@app.route('/help', methods=['GET', 'POST'])
def buzz_help():
    return render_template('help.html')


@app.route('/uploads/<name>', methods=['GET', 'POST'])
def download_file(name):
    return send_from_directory(app.config['UPLOAD_FOLDER'], name)


@app.route('/bl', methods=['GET', 'POST'])
def bl():
    if request.method == 'POST':
        BZ.blid = str(request.form.get('blid'))
        if not BZ.blid:
            return render_template('bl.html', message='Please enter a valid BL record ID.')
        if not re.match(r'^[0-9]{9}$', BZ.blid):
            return render_template('bl.html', message='Please enter a valid BL record ID, consisting of nine numeric digits.')
        BZ.writer = MARCWriter(open(os.path.join(app.config['OUTPUT_FOLDER'], BZ.blid + '.lex'), mode='wb'))
        BZ.pos_input_records = 0
        try:
            conn = zoom.Connection('z3950cat.bl.uk', 9909, user='COLMET2912', password='2m5v2Qyv')
        except Exception as e:
            print(str(e))
        conn.databaseName = 'ZBLACU'
        conn.preferredRecordSyntax = 'USMARC'
        query = zoom.Query(f'id="{BZ.blid}"')
        res = conn.search(query)
        try:
            BZ.input_records[0] = res[0]
        except:
            conn.close()
            return render_template('bl.html', message='Sorry, that record could not be found.')
        conn.close()
        return render_template('process_bl.html', blid=BZ.blid, record=BZ.input_records[0])
    return render_template('bl.html')


@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        # If the user does not select a file, the browser submits an empty file without a filename.
        if file.filename == '':
            return redirect(request.url)
        if file and allowed_file(file.filename):
            BZ.filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], BZ.filename))
            return redirect(url_for('process'))
    return render_template('upload.html')


@app.route('/process', methods=['GET', 'POST'])
def process():
    if not BZ.filename:
        return redirect(url_for('upload'))

    with open(os.path.join(app.config['UPLOAD_FOLDER'], BZ.filename), mode='rb') as f:
        BZ.num_input_records = f.read().count(29)

    BZ.reader = MARCReader(open(os.path.join(app.config['UPLOAD_FOLDER'], BZ.filename), mode='rb'))
    BZ.writer = MARCWriter(open(os.path.join(app.config['OUTPUT_FOLDER'], BZ.filename), mode='wb'))
    BZ.pos_input_records = 1
    BZ.input_records[1] = BZ.reader.__next__()
    return render_template('process.html', filename=BZ.filename, num_input_records=BZ.num_input_records,
                           pos_input_records=BZ.pos_input_records, record=BZ.input_records[1])


@app.route('/record_number', methods=['GET'])
def record_number():
    return str(BZ.pos_input_records)


@app.route('/next_record', methods=['GET', 'POST'])
def next_record():
    if request.method == 'POST':
        if request.form['action'] == 'save':
            r = Record()
            r.from_string(request.form.get('locked_marc'))
            r.from_string(request.form.get('editable_marc'))
            BZ.input_records[BZ.pos_input_records] = r
            BZ.writer.write(record=BZ.input_records[BZ.pos_input_records])
        if BZ.pos_input_records < BZ.num_input_records:
            BZ.pos_input_records += 1
            BZ.input_records[BZ.pos_input_records] = BZ.reader.__next__()
            return render_template('marc.html', num_input_records=BZ.num_input_records, pos_input_records=BZ.pos_input_records,
                                   record=BZ.input_records[BZ.pos_input_records])
        return render_template('finished_inner.html', filename=BZ.filename)


@app.route('/download', methods=['GET', 'POST'])
def download():
    BZ.writer.flush()
    print(app.config['OUTPUT_FOLDER'] + BZ.filename)
    return send_from_directory(directory=app.config['OUTPUT_FOLDER'], path=BZ.filename, mimetype='application/octet-stream', as_attachment=True)


@app.route('/saveBL', methods=['GET', 'POST'])
def save_BL_record():
    r = Record()
    r.from_string(request.form.get('locked_marc'))
    r.from_string(request.form.get('editable_marc'))
    BZ.input_records[BZ.pos_input_records] = r


@app.route('/downloadBL/<path:name>')
def download_bl(name):
    BZ.writer.write(record=BZ.input_records[BZ.pos_input_records])
    BZ.writer.flush()
    return send_from_directory(directory=app.config['OUTPUT_FOLDER'], path=name, mimetype='application/octet-stream', as_attachment=True)


@app.route('/search_oclc', methods=['GET', 'POST'])
def search_oclc():
    if request.method == 'POST':
        if request.form['action'] == 'new_search':
            BZ.title, BZ.au, BZ.isbn, BZ.query, BZ.z_records = BZ.input_records[BZ.pos_input_records].search_oclc()
            BZ.num_z_records = len(BZ.z_records)
            return render_template('oclc.html', z_records=BZ.z_records, num_z_records=BZ.num_z_records, query=BZ.query, title=BZ.title, au=BZ.au, isbn=BZ.isbn, pos_input_records=BZ.pos_input_records, num_input_records=BZ.num_input_records)
    return render_template('oclc.html', pos_input_records=BZ.pos_input_records, num_input_records=BZ.num_input_records)


@app.route('/search_again', methods=['GET', 'POST'])
def search_again():
    if request.method == 'POST':
        BZ.title = request.form.get('title')
        BZ.au = request.form.get('au')
        BZ.isbn = request.form.get('isbn')
        q = construct_query(BZ.title, BZ.au, BZ.isbn)
        BZ.query, BZ.z_records = run_search(q)
        BZ.num_z_records = len(BZ.z_records)
        return render_template('oclc.html', z_records=BZ.z_records, num_z_records=BZ.num_z_records, query=BZ.query, title=BZ.title, au=BZ.au, isbn=BZ.isbn, pos_input_records=BZ.pos_input_records, num_input_records=BZ.num_input_records)
    return render_template('oclc.html', pos_input_records=BZ.pos_input_records, num_input_records=BZ.num_input_records)


@app.route('/validate', methods=['GET', 'POST'])
def validate():
    if request.method == 'POST':
        r = Record()
        r.from_string(request.form.get('locked_marc'))
        r.from_string(request.form.get('editable_marc'))
        BZ.input_records[BZ.pos_input_records] = r
        valid, errors = r.validate()
        print(valid)
        print(errors)
        return render_template('validation.html', valid=valid, errors=errors, pos_input_records=BZ.pos_input_records, num_input_records=BZ.num_input_records)
    return render_template('validation.html', pos_input_records=BZ.pos_input_records, num_input_records=BZ.num_input_records)

@app.route('/edit_record', methods=['GET', 'POST'])
def edit_record():
    if request.method == 'POST':
        r = Record()
        r.from_string(request.form.get('locked_marc'))
        r.from_string(request.form.get('editable_marc'))
        if request.form['action'] == 'add_single':
            r.add_field(get_field_from_string(html.unescape(request.form.get('field'))))
        if request.form['action'] == 'add_multiple':
            fields = request.form.get('fields')
            for field in fields.split('\n'):
                r.add_field(get_field_from_string(html.unescape(field)))
        BZ.input_records[BZ.pos_input_records] = r
    return render_template('marc.html', num_input_records=BZ.num_input_records,
                           pos_input_records=BZ.pos_input_records,
                           record=BZ.input_records[BZ.pos_input_records])



@app.route('/transliterate', methods=['GET', 'POST'])
def trans():
    if request.method == 'POST':
        script_from = request.form.get('from')
        script_to = request.form.get('to')
        field = get_field_from_string(html.unescape(request.form.get('text')))
        r = Record()
        r.from_string(request.form.get('locked_marc'))
        r.from_string(request.form.get('editable_marc'))
        count_880 = len(r.get_fields('880'))
        if field.tag.isdigit() and 100 <= int(field.tag) < 852 and '6' not in field:
            subfields = []
            for subfield in field:
                code, content = subfield
                content = html.unescape(content)
                _, pre, content, post, _ = re.split(r'^([ :;\(\[{\'"#.,/\\\-]*)(.*?)([ :;\)\]}\'"#.,/\\!\?\-]*)$', content)
                new_content = transliterate.process(script_from, script_to, unicodedata.normalize('NFC', content))
                subfields.extend([code, pre + new_content + post])
            count_880 += 1
            new_field = Field(tag='880', indicators=field.indicators, subfields=['6', f'{field.tag}-{count_880:02d}'] + subfields)
            field.subfields = ['6', f'880-{count_880:02d}'] + field.subfields
            return f'{str(field)}\n{str(new_field)}'
        return 'Cannot transliterate this field'
    return None

if __name__ == "__main__":
    app.run(port=4204, debug=True)

#TODO update 005
#TODO download BL record is not working
#TODO z3950 query is not specific enough. Check that it is doing what it should, and add more attributes?
