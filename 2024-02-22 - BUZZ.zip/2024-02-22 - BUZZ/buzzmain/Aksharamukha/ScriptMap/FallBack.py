specificPairsPre = {
    'ALALCBurmese': {
    },
    'BurmeseALALC': {
    }
}

specificPairsPost = {
    'BurmeseALALC-ALALCBurmese': {
        "၏": "e*",
        "၌": 'n*',
        '၍': 'r*',
        '၎': 'l*'
    },
    'ALALCBurmese': {
    },
    'BurmeseALALC': {
    }
}