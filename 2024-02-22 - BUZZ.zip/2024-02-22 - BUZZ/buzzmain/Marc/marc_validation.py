#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re

OBSOLETE_FIELDS = ['009', '011', '090', '090', '091', '211', '212', '214', '241', '265',
                   '301', '302', '303', '304', '305', '308', '315', '350', '359',
                   '440', '503', '512', '517', '523', '527', '537', '543', '570', '582', '590', '590',
                   '652', '705', '715', '755', '840', '851', '870', '871', '872', '873']
UNDESIRABLE_FIELDS = {'260': 'Prefer field 264.',
                      '720': 'Prefer a controlled field in the 7xx block.',
                      '653': 'Prefer a controlled subject term in the 6xx block.'}
NON_REPEATABLE_FIELDS = ['008', '010', '018', '036', '038', '040', '042', '044', '045', '066',
                         '100', '110', '111', '130', '240', '243', '245', '254', '256', '261', '262', '263',
                         '306', '357', '507', '514', '655', '841', '842', '844', '882']
MANDATORY_FIELDS = ['LDR', '001', '040', '008', '245']
DESIRABLE_FIELDS = ['1xx', '264', '300', '336', '337', '338']

ABBREVIATIONS = {
    re.compile(r'\bpp*\b\.?'): 'pages',
    re.compile(r'\billu?s?\b\.?'): 'illustrations',
    re.compile(r'\bfacsi?m?s?\b\.?'): 'facsimiles',
    re.compile(r'\bgeneal\b\.?'): 'genealogical',
    re.compile(r'\bports?\b\.?'): 'portraits',
    re.compile(r'\bcol\b\.?'): 'colour or column(s)',
    re.compile(r'\bmins?\b\.?'): 'minute(s) or miniature',
}