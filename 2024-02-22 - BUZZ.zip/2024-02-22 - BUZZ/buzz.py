#!/usr/bin/env python
from buzzmain.app import *

app.run(port=4024, debug=True)
