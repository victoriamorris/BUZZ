python setup.py install  --install-lib "C:\Python installation"
python -m PyInstaller buzz.py -F --add-data "buzzmain/templates;templates" --add-data "buzzmain/static;static" --add-data "buzzmain/Aksharamukha;aksharamukha" --icon=buzzmain/static/favicon.ico
read -p "Press [Enter]"
mv dist/buzz.exe buzz.exe
rm -rfd dist
rm -rfd __pycache__
rm -rfd build
rm -rfd buzz.egg-info
rm buzz.spec
read -p "Press [Enter]"